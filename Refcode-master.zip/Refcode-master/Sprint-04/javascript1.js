// GUESSING GAME:

// There are some variables with values
var ten = 10;
var pickle = 3;

// Q: What is the value of the variable `pickle`?
// A:

var twiceTen = ten + ten;
// Q: What is the value of `twiceTen`?
// A:

var twiceTwo = pickle + pickle;
// Q: What is the value of `twicePickle`?
// A:

var fiveTimesTen = ten * 5;
// Q: What is the value of `fiveTimesTen`?
// A:

var big = 100;
var small = 2;

var divide = big / small;

// Q: What is the value of `divide`?
// A:


// EXERCISES:

// Some vars
var big = 100;
var small = 2;

// In the area below, write a variable named `sum` that adds the big number to the small number
// You will see the word `undefined`, which you need to replace with the correct expression.

var sum = undefined;

// Top 5 Tallest Buildings and how many floors they have

var burjKhalifa = 163;
var shanghaiTower = 128;
var abrajAlBait = 120;
var pingAn = 115;
var lotte = 123;

// Create a variable that calculates the total number of floors of each building.
// The total is calculated by adding all five values together
var totalFloors = undefined;

// Create a variable that calculates the average number of floors.
// The average is calculated by dividing the total by the number of items (in our case, five)
var average = undefined;

// Objects
var brenton = {
    height: "five foot eleven",
    eyeColor: "brown",
    hairColor: "brown",
};

// Q: How would you programmatically retreive the value of `brenton`'s `height`?
// A:

// Q: How would you get the value of the property `eyeColor` in the object `brenton`?
// A:


var america = {
    georgia: {
        atlanta: {
            population: 472522,
        },
        clarkston: {
            population: 7554,
        },
        alpharetta: {
            population: 57551,
            }
        },
    },
};

// Q: How would you get the value of Clarkston's population?
// A:
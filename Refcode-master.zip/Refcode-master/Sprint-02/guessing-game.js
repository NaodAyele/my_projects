// GUESSING GAME!
// Below you will find some sections of code with one or more questions about that code.
// Write your answer to each question on the line after A:
// You don't have to know the answer, but you do have to guess!

x = 5;

// Q: In the code above, what is the value of `x`?
// A:

myVariable = 23;

// Q: In the code above, what is the value of `myVariable`?
// A:

a = 23;
b = 45;
d = 99;

// Q: In the code above, what is the value of `c`?
// A:

foo = 1;
bar = 2;
baz = 3;
qux = 4;

// Q: In the code above, what is the name of the variable that has the value 3?
// A:

thud = 5;
thud = 1;

// Q: In the code above, what is the value of `thud`?
// A:

brenton = -100;
brenton = 5.5;
brenton = 0;
dinosaur = -200;
dinosaur = 8;
dinosaur = 999999;

// Q: In the code above, what is the value of `dinosaur`?
// A:
// Q: In the code above, all of the variables above are "number" type. What do you think are the possible values of the number type?
// A:

x = 1;
y = x;

// Q: In the code above, what is the value of `x`?
// A:
// Q: What is the value of `y`?
// A:
// Q: Are `x` and `y` the same, or are they different?
// A:

one = 1;
two = 2;
three = 3;
five = 5;
six = 6;

// Q: What is the value of `four`?
// A:
// GUESSING GAME!
// Below you will find some sections of code with one or more questions about that code.
// Write your answer to each question on the line after A:

someWords = "This is some words!";

// Q: What is the value of `someWords`?
// A:

aNumber = 4;
aString = "4";

// Q: What is the value of `aNumber`? What makes it different from `aString`?
// A:

aString = "true";
aBoolean = true;

// Q: What is the value of `aBoolean`? What makes it different from `aString`?
// A:

question0 = true;
question1 = false;
question2 = true;
question3 = false;
question4 = false;
question5 = true;
question6 = true;

// All of the variables above have a value that is "boolean" type.
// Q: What do you think are the possible values of a boolean type variable?
// A:

foo = true;
bar = "true"
baz = 1;

// Q: What is the name of the variable that is a "string" type?
// A:
// Q: What is the name of the variable that is a "number" type?
// A:
// Q: What is the name of the variable that is a "boolean" type?
// A:














foo, bar, baz, qux, quux, corge, uier, grault, garply, waldo, fred, plugh, thud, mos, henk, def.